package analisador;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.TextArea;
import java.awt.Label;

public class Main2 {

	private JFrame frame;
	private Label labelHora;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main2 window = new Main2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main2() {
		initialize();
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 513);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		//Areas onde imprime as frequ�ncias
		TextArea textDia = new TextArea();
		textDia.setBounds(10, 79, 664, 92);
		frame.getContentPane().add(textDia);
		
		TextArea textHora = new TextArea();
		textHora.setBounds(10, 220, 664, 77);
		frame.getContentPane().add(textHora);
		
		TextArea textBrowser = new TextArea();
		textBrowser.setBounds(10, 340, 664, 92);
		frame.getContentPane().add(textBrowser);
		
		JButton btnEnviarLog = new JButton("Enviar Log");
		btnEnviarLog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ArrayList<Acesso> lista = ControleLog.retornaLog2();
				
				//Devolve uma array com a frequencia: Xi / fi / FI / fr / FR / Xi*fi / (Xi-X)�*fi
				ArrayList<Frequencia> frequenciaHora = Calculos.tabelaFrequenciaHora(lista);
				
				//Metodo retorna uma array com a frequencia: Xi / fi / FI / fr / FR / Xi*fi / (Xi-X)�*fi
				ArrayList<Frequencia> frequenciaDia = Calculos.tabelaFrequenciaDia(lista);
				
				//Devolve uma array com a frequencia: Xi / fi / FI
				ArrayList<Frequencia> frequenciaBrowser = Calculos.tabelaFrequenciaBrowser(lista);
				
				//Preenche o textArea de Dia
				String tDia = "";
				for (Frequencia f : frequenciaDia) {
					if(f.getXiNumero()!=0) {
						//Usa o toString escrito para Dia
						tDia+=f.imprimeFreqDia()+"\n";
					}
				}
				textDia.setText(tDia);
				
				
				//Preenche o textArea de Hora
				String tHora = "";
				for (Frequencia f : frequenciaHora) {
					if(f.getXiNumero()!=0) {
						//Usa o toString escrito para Hora
						tHora+=f.imprimeFreqHora()+"\n";
					}
				}
				textHora.setText(tHora);
				
				
				//Preenche o textArea de browser
				String tBrowser = "";
				for (Frequencia f : frequenciaBrowser) {
					//Usa o toString escrito para Hora
					tBrowser+=f.imprimeFreqTexto()+"\n";
				}
				textBrowser.setText(tBrowser);
				
								
			}
		});
		btnEnviarLog.setBounds(262, 11, 159, 23);
		frame.getContentPane().add(btnEnviarLog);
		
		
		Label labelDia = new Label("Frequ\u00EAncia de Acessos por dia");
		labelDia.setBounds(10, 51, 224, 22);
		frame.getContentPane().add(labelDia);
		
		labelHora = new Label("Frequ\u00EAncia de Acessos por hora");
		labelHora.setBounds(10, 192, 224, 22);
		frame.getContentPane().add(labelHora);
		
		Label labelBrowser = new Label("Frequ\u00EAncia de Acessos por Navegador");
		labelBrowser.setBounds(10, 312, 224, 22);
		frame.getContentPane().add(labelBrowser);
		
		
	}
}
