package analisador;

import java.text.DecimalFormat;

public class Frequencia {
	
	private static DecimalFormat dfReal = new DecimalFormat("###,###,##0.00");
	private static DecimalFormat dfInteiro = new DecimalFormat("###,###,##0");
	
	private double xiNumero;
	private String xiTexto;
	private int fi;
	private int FiAcumulado;
	private double fr;
	private double frAcumulado;
	private double xifi;
	private double xiMedia;
	
	public String imprimeFreqDia() {
		return "xi=" + dfInteiro.format(xiNumero) + ", fi=" + dfInteiro.format(fi) + ", Fi=" + dfInteiro.format(FiAcumulado)
		+ ", fr=" + dfReal.format(fr) + ", Fr=" + dfReal.format(frAcumulado) + ", xifi=" + dfReal.format(xifi)
		+ ", xiMedia=" + dfReal.format(xiMedia) ;
	}
	
	public String imprimeFreqHora() {
		return "xi=" + dfReal.format(xiNumero) + ", fi=" + dfInteiro.format(fi) + ", Fi=" + dfInteiro.format(FiAcumulado)
		+ ", fr=" + dfReal.format(fr) + ", Fr=" + dfReal.format(frAcumulado) + ", xifi=" + dfReal.format(xifi)
		+ ", xiMedia=" + dfReal.format(xiMedia) ;
	}
	
	public String imprimeFreqTexto() {
		return "xi=" + xiTexto + ", fi=" + dfInteiro.format(fi) + ", Fi="+ dfInteiro.format(FiAcumulado);
	}

	public Frequencia() {

	}

	public Frequencia(double xiNumero, int fi, int fiAcumulado, double fr, double frAcumulado, double xifi,
			double xiMedia) {
		super();
		this.xiNumero = xiNumero;
		this.fi = fi;
		FiAcumulado = fiAcumulado;
		this.fr = fr;
		this.frAcumulado = frAcumulado;
		this.xifi = xifi;
		this.xiMedia = xiMedia;
	}
	
	public Frequencia(String xiTexto, int fi, int fiAcumulado, double fr, double frAcumulado, double xifi,
			double xiMedia) {
		super();
		this.xiTexto = xiTexto;
		this.fi = fi;
		FiAcumulado = fiAcumulado;
		this.fr = fr;
		this.frAcumulado = frAcumulado;
		this.xifi = xifi;
		this.xiMedia = xiMedia;
	}
	public double getXiNumero() {
		return xiNumero;
	}
	public void setXiNumero(double xiNumero) {
		this.xiNumero = xiNumero;
	}
	public String getXiTexto() {
		return xiTexto;
	}
	public void setXiTexto(String xiTexto) {
		this.xiTexto = xiTexto;
	}
	public int getFi() {
		return fi;
	}
	public void setFi(int fi) {
		this.fi = fi;
	}
	public int getFiAcumulado() {
		return FiAcumulado;
	}
	public void setFiAcumulado(int fiAcumulado) {
		FiAcumulado = fiAcumulado;
	}
	public double getFr() {
		return fr;
	}
	public void setFr(double fr) {
		this.fr = fr;
	}
	public double getFrAcumulado() {
		return frAcumulado;
	}
	public void setFrAcumulado(double frAcumulado) {
		this.frAcumulado = frAcumulado;
	}
	public double getXifi() {
		return xifi;
	}
	public void setXifi(double xifi) {
		this.xifi = xifi;
	}
	public double getXiMedia() {
		return xiMedia;
	}
	public void setXiMedia(double xiMedia) {
		this.xiMedia = xiMedia;
	}
	
	

}
