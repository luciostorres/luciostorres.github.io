package analisador;

public class Acesso {

    private String usuario, ip, data, browser;
    
    //ADI��O
    private int hora;
    
    public int getHora() {
		return hora;
	}

	public void setHora(int hora) {
		this.hora = hora;
	}
	//FIM DA ADI��O

	public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }

    public Acesso() {
    }

    public Acesso(String usuario, String ip, String data, String browser) {
        this.usuario = usuario;
        this.ip = ip;
        this.data = data;
        this.browser = browser;
    }

    @Override
    public String toString() {
        return "Acesso{" + "usuario=" + usuario + ", ip=" + ip + ", data=" + data + ", browser=" + browser + '}';
    }
    
    
    
}
