package analisador;

import java.util.ArrayList;
import java.util.Collections;

public class Calculos {

	private static ArrayList<Frequencia> frequenciaCalculada = new ArrayList<Frequencia>();

	private static int n;
	private static double media;

	public static ArrayList<Frequencia> tabelaFrequenciaHora(ArrayList<Acesso> lista){

		frequenciaCalculada = new ArrayList<Frequencia>();

		preencheXiHora(lista);
		calculaFr();
		calculaXiFiMedia();

		return frequenciaCalculada;
	}

	public static ArrayList<Frequencia> tabelaFrequenciaDia(ArrayList<Acesso> lista){

		frequenciaCalculada = new ArrayList<Frequencia>();

		preencheXiDia(lista);
		calculaFr();
		calculaXiFiMedia();

		return frequenciaCalculada;
	}

	public static ArrayList<Frequencia> tabelaFrequenciaBrowser(ArrayList<Acesso> lista){

		frequenciaCalculada = new ArrayList<Frequencia>();

		preencheXiBrowser(lista);

		return frequenciaCalculada;
	}

	public static void preencheXiHora(ArrayList<Acesso> lista) {

		ArrayList<Integer> horas = new ArrayList <Integer>();

		n=lista.size();

		for (Acesso a : lista) {
			horas.add(a.getHora());
		}

		Collections.sort(horas);

		//variáveis para marcar as classes e fazer as contagens
		double finalClasse = 1;
		double inicioClasse = horas.get(0);
		double xi = (inicioClasse+finalClasse)/2;
		int fi=1;
		int acumulado=1;

		Frequencia f = new Frequencia();

		//Tranferir do vetor para a ArrayList e já contar a fi e Fi
		for (int i = 0; i < horas.size(); i++) {
			if(i==0) {
				f.setXiNumero(xi);
				f.setFi(fi);
				fi++;
				f.setFiAcumulado(acumulado);
				acumulado++;

			}else if(horas.get(i) < finalClasse) {
				f.setFi(fi);
				fi++;
				f.setFiAcumulado(acumulado);
				acumulado++;
			}else {
				frequenciaCalculada.add(f);

				f= new Frequencia();

				fi=1;
				inicioClasse = finalClasse;
				finalClasse ++;
				xi = (inicioClasse+finalClasse)/2;
				f.setXiNumero(xi);
				f.setFi(fi);
				fi++;
				f.setFiAcumulado(acumulado);
				acumulado++;
			}
		}
		//guarda o ultimo Xi
		frequenciaCalculada.add(f);
	}

	public static void preencheXiDia(ArrayList<Acesso> lista) {
		
		n=lista.size();

		//array de String pra guardar as datas recebidas
		ArrayList<String> datas = new ArrayList <String>();
		
		for (int i = 0; i < lista.size(); i++) {
		
			datas.add(lista.get(i).getData());
			
		}

		//array de inteiros pra guardar a quantidade de acessos no dia		
		ArrayList<Integer> contagemDeAcessos = new ArrayList <Integer>();
		
		int contadorXi=1;
		String anterior=datas.get(0);

		int k = 0;

		//Tranferir do vetor para a ArrayList, transformando a Data na Xi
		for (int i = 0; i < datas.size(); i++) {
			if(i==0) {
				k=contadorXi;
				contadorXi++;
			}else{
				if(datas.get(i).equalsIgnoreCase(anterior)) {
					k=contadorXi;
					contadorXi++;
				}else {
					//Adiciona os itens cadastrados (Xi, fi e Fi) na array de frequencia
					contagemDeAcessos.add(k);
					
					//seta as variáveis locais
					contadorXi=1;
					anterior= datas.get(i);
					k=contadorXi;
					contadorXi++;
				}
			}
		}
		contagemDeAcessos.add(k);

		Collections.sort(contagemDeAcessos);

		int fi=1;
		int acumulado=1;


		Frequencia f = new Frequencia();

		//Tranferir do vetor para a ArrayList e já contar a fi e Fi
		for (int i = 0; i < contagemDeAcessos.size(); i++) {
			if(i==0) {
				f.setXiNumero(contagemDeAcessos.get(i));
				f.setFi(fi);
				fi++;
				f.setFiAcumulado(acumulado);
				acumulado++;

			}else if(contagemDeAcessos.get(i) < f.getFi()) {
				f.setFi(fi);
				fi++;
				f.setFiAcumulado(acumulado);
				acumulado++;
			}else {
				frequenciaCalculada.add(f);

				f= new Frequencia();

				fi=1;				
				f.setFi(fi);
				fi++;
				f.setFiAcumulado(acumulado);
				acumulado++;
				f.setXiNumero(contagemDeAcessos.get(i));
			}
		}
		frequenciaCalculada.add(f);
	}

	public static void preencheXiBrowser(ArrayList<Acesso> lista) {

		n=lista.size();

		ArrayList<String> browser = new ArrayList <String>();

		for (Acesso a : lista) {
			browser.add(a.getBrowser());
		}

		Collections.sort(browser);

		int fi=1;
		int acumulado=1;
		String anterior="";

		Frequencia freqLocal = new Frequencia();

		for (int i = 0; i < browser.size(); i++) {
			if(i==0) {
				//Guarda primeiro item digitado
				freqLocal.setXiTexto(browser.get(i));
				freqLocal.setFi(fi);
				anterior = browser.get(i);
				fi++;
			}else if(browser.get(i).equalsIgnoreCase(anterior)) {
				freqLocal.setFi(fi);
				fi++;
			}else {
				//guarda a Fi da frequencia local e reescreve a Fi local
				freqLocal.setFiAcumulado(acumulado+fi-1);
				acumulado = freqLocal.getFiAcumulado();

				//Adiciona os itens cadastrados (Xi, fi e Fi) na array de frequencia
				frequenciaCalculada.add(freqLocal);

				//zera a variavel local e começa a inserir as informações novamente
				freqLocal = new Frequencia();
				fi=1;

				freqLocal.setXiTexto(browser.get(i));
				freqLocal.setFi(fi);
				n++;
				anterior = browser.get(i);

				fi++;
			}
		}
		freqLocal.setFiAcumulado(acumulado+fi-1);
		frequenciaCalculada.add(freqLocal);

	}


	public static void calculaFr() {

		//Variavel para controlar o acumulado
		double frAcumulada = 0;

		//objeto local para os calculos de Fr
		ArrayList <Frequencia> local = new ArrayList<Frequencia>();
		Frequencia freqLocal = new Frequencia();

		for (int j = 0; j < frequenciaCalculada.size(); j++) {
			freqLocal=frequenciaCalculada.get(j);

			double fr=(double)(freqLocal.getFi()*100)/n;
			freqLocal.setFr(fr);

			frAcumulada += freqLocal.getFr();
			freqLocal.setFrAcumulado(frAcumulada);

			local.add(freqLocal);

			freqLocal = new Frequencia();
		}
		local.add(freqLocal);

		frequenciaCalculada = local;

	}

	public static void calculaXiFiMedia() {

		ArrayList <Frequencia> local = new ArrayList<Frequencia>();

		//objeto local para os calculos de Xi*Fi
		Frequencia freqLocal = new Frequencia();

		double xifiAcumulado = 0;

		for (int j = 0; j < frequenciaCalculada.size(); j++) {
			freqLocal=frequenciaCalculada.get(j);

			double xifi = (double) freqLocal.getXiNumero()* freqLocal.getFi();
			freqLocal.setXifi(xifi);
			xifiAcumulado+=xifi;

			local.add(freqLocal);

			freqLocal = new Frequencia();
		}
		local.add(freqLocal);

		frequenciaCalculada = local;

		media = (double)xifiAcumulado/n;
		
		//renova a variável local
		local = new ArrayList<Frequencia>();

		for (int i = 0; i < frequenciaCalculada.size(); i++) {
			//transfere da variável global para o objeto local
			freqLocal=frequenciaCalculada.get(i);

			double xixfi = Math.pow((freqLocal.getXiNumero()-media),2)*freqLocal.getFi();
			freqLocal.setXiMedia(xixfi);

			local.add(freqLocal);

			//zera o objeto local
			freqLocal = new Frequencia();
		}
		local.add(freqLocal);

		frequenciaCalculada = local;

	}


}
