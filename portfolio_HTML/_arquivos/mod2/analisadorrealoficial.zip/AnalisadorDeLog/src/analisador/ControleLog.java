package analisador;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ControleLog {

	static final String NOME_ARQ = "C:/Users/l-s-t/Desktop/Logs.txt";
	static final String SEPARADOR = ";";

	public static ArrayList<Acesso> retornaLog(){

		ArrayList<Acesso> lista = new ArrayList<Acesso>();

		try {
			BufferedReader reader = new BufferedReader(new FileReader(NOME_ARQ));

			String linha = "";
			while (linha != null) {
				linha = reader.readLine();
				if (linha != null) {
					Acesso dado = new Acesso();
					String array[] = linha.split(SEPARADOR);
					dado.setUsuario(array[0]);
					dado.setIp(array[1]);
					dado.setData(array[2]);
					dado.setBrowser(array[3]);
					lista.add(dado);
				}
			}
			reader.close();
			return lista;
		} catch (Exception e) {
			return lista;
		}
	}

	//ALTERA��O PARA BUSCAR O ARQUIVO QUE O USU�RIO DEFINIR
	public static ArrayList<Acesso> retornaLog2(){

		String caminho = encontrarArquivo();
		
		ArrayList<Acesso> lista = new ArrayList<Acesso>();

		try {
			BufferedReader reader = new BufferedReader(new FileReader(caminho));

			String linha = "";
			while (linha != null) {
				//ALTERA��O NO SPLIT PARA USAR O ARQUIVO QUE O TSUKAS PASSOU
				linha = reader.readLine();
				if (linha != null) {
					Acesso dado = new Acesso();
					String array[] = linha.split(" ");
					dado.setIp(array[0]);//O IP FICA NA 1� POSI��O DO ARRAY
					dado.setData(array[3].substring(1, 12));//A DIA FICA NO CHARS 1 � 11 NA 4� POSI��O DA ARRAY
					dado.setHora(Integer.parseInt((array[3].substring(13, 15))));
					dado.setBrowser(array[11].replace("\"", ""));//NAVEGADOR FICA NA POSI��O 11 - j� retira o " do arquivo
					lista.add(dado);
				}
			}
			reader.close();
			return lista;
		} catch (Exception e) {
			return lista;
		}
	}


	public static String encontrarArquivo() {
		String caminho = "";

		try {
			//Cria um file chooser
			JFileChooser fc = new JFileChooser();
			FileNameExtensionFilter filter = new FileNameExtensionFilter("LOG FILES", "log", "text");
			fc.setFileFilter(filter);
			int returnVal = fc.showOpenDialog(null);

			//Verifica se ouve a escolha do arquivo
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File file = fc.getSelectedFile();
				caminho=file.getAbsolutePath();
			}

		} catch (Exception e) {

		}

		return caminho;
	}

}



